#include "Axis.h"

// ���� �� ������ ����
const VERTEX AXIS::lineVertices[6] = {
	// x�� (����)
	{ -0.8f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f },
	{  0.8f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f },

	// y�� (�ʷ�)
	{ 0.0f, -0.8f, 0.0f, 0.0f, 1.0f, 0.0f },
	{ 0.0f,  0.8f, 0.0f, 0.0f, 1.0f, 0.0f },

	// z�� (�Ķ�)
	{ 0.0f, 0.0f, -0.8f, 0.0f, 0.0f, 1.0f },
	{ 0.0f, 0.0f,  0.8f, 0.0f, 0.0f, 1.0f }
};

void AXIS::init(GLuint shaderProgramID) {
	this->GetShaderProgramID(shaderProgramID);

	// ��
	glGenVertexArrays(1, &AxisVAO_);
	glGenBuffers(1, &AxisVBO_);
	glBindVertexArray(AxisVAO_);
	glBindBuffer(GL_ARRAY_BUFFER, AxisVBO_);

	glBufferData(GL_ARRAY_BUFFER, sizeof(lineVertices), lineVertices, GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VERTEX), (GLvoid*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VERTEX), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

void AXIS::DrawRotated(float angleDegrees) {
	// 30�� ȸ�� ��� ����
	glm::mat4 rotationMatrix = glm::rotate(glm::mat4(1.0f),
		glm::radians(angleDegrees),
		glm::vec3(0.0f, 0.0f, 1.0f)); // Z�� ���� ȸ��

	Draw(rotationMatrix);
}

void AXIS::Draw(const glm::mat4& modelMatrix) {
	glUseProgram(shaderProgramID_);

	GLint modelLoc = glGetUniformLocation(shaderProgramID_, "modelMat");
	glm::mat4 axisModel = glm::mat4(1.0f); // ���� ��� (ȸ�� ����)
	axisModel = glm::scale(axisModel, glm::vec3(4.0f, 4.0f, 4.0f)); // ũ�� ���� (�ʿ��)
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(axisModel));

	// ���̴��� ��ȯ ��� ����
	GLuint modelMatrixLocation = glGetUniformLocation(shaderProgramID_, "rotateAxis");
	glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	glBindVertexArray(AxisVAO_);
	glDrawArrays(GL_LINES, 0, 6);
	glBindVertexArray(0);
}